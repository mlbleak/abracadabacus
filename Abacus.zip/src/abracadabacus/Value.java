package abracadabacus;

/**
 * Determines whether the bead is worth 5 or worth 1
 * 
 * @author Myron Burton
 *
 */
public enum Value {
	FIVES,ONES
}
