package abracadabacus;

/**
 * Determines whether the bead has a value or not
 * 
 * @author Myron Burton
 *
 */
public enum Position {
	NOT_COUNTED, COUNTED
}
