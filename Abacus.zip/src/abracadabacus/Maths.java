package abracadabacus;

public enum Maths {
	PLUSONE, MINUSONE;
}
