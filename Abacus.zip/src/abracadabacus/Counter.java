package abracadabacus;

/**
 * Determines whether the bead has a value or not
 * 
 * @author Myron Burton
 *
 */
public enum Counter {
	NOT_COUNTED, COUNTED
}
